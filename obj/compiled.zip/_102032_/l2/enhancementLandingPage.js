/// <mls fileReference="_102032_/l2/enhancementLandingPage.ts" enhancement="_blank"/>
import { convertFileNameToTag } from '/_102027_/l2/utils.js';
import { getPropierties } from '/_102027_/l2/propiertiesLit.js';
import { validateTagName, validateRender } from '/_102027_/l2/validateLit.js';
import { setCodeLens } from '/_102027_/l2/codeLensLit.js';
import { injectStyle, injectStyleAction } from '/_102027_/l2/processCssLit.js';
export const requires = [
    {
        type: 'tspath',
        name: 'lit',
        ref: "file://server/_102027_/l2/litElement.ts"
    },
    {
        type: 'tspath',
        name: 'lit/decorators.js',
        ref: "file://server/_102027_/l2/decorators.ts"
    },
    {
        type: "cdn",
        name: "lit",
        ref: "https://cdn.jsdelivr.net/gh/lit/dist@3/all/lit-all.min.js",
    },
    {
        type: "cdn",
        name: "lit/decorators.js",
        ref: "https://cdn.jsdelivr.net/npm/lit@3.0.0/decorators/+esm",
    },
    {
        type: "link",
        name: "fontAwesome",
        ref: 'https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.6.0/css/all.min.css',
        rel: 'stylesheet',
    },
    {
        type: "import",
        name: "tailwind.js",
        ref: "https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4",
    }
];
export const getDefaultHtmlExamplePreview = (modelTS) => {
    const { project, shortName, folder } = modelTS.storFile;
    const tag = convertFileNameToTag({ project, shortName, folder });
    return `<${tag}></${tag}>`;
};
export const getDesignDetails = async (modelTS) => {
    return new Promise((resolve, reject) => {
        try {
            const ret = {
                defaultGroupName: "",
                defaultHtmlExamplePreview: getDefaultHtmlExamplePreview(modelTS),
                properties: getPropierties(modelTS),
                webComponentDependencies: []
            };
            resolve(ret);
        }
        catch (e) {
            reject(e);
        }
    });
};
export const onAfterChange = async (modelTS) => {
    try {
        setCodeLens(modelTS);
        if (validateTagName(modelTS)) {
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'left');
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'right');
            return;
        }
        if (validateRender(modelTS)) {
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'left');
            mls.events.fireFileAction('statusOrErrorChanged', modelTS.storFile, 'right');
            return;
        }
    }
    catch (e) {
        return e.message || e;
    }
};
export const onAfterCompile = async (modelTS) => {
    await injectStyle(modelTS, 'Default', '_102032_enhancementLandingPage');
    return;
};
export const onAfterCompileAction = async (sourceJS, sourceTS, css) => {
    return await injectStyleAction(sourceJS, sourceTS, css?.sourceLess || '', css?.sourceTokens || '', 'Default', '_102032_enhancementLandingPage');
};
